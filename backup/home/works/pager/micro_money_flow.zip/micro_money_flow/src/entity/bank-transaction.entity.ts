import { BaseEntity, Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";
import { ICommonTransaction } from "../transaction_file_loader/interface/transaction.interface";
import { BankAccountName } from "../transaction_file_loader/interface/banks.enum";

@Entity('bank_transaction')
export class BankTransaction implements ICommonTransaction {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column('varchar')
    bankAccountName: BankAccountName;

    @Index()
    @Column('timestamptz')
    transactionDatatime: Date;

    @Column('int')
    transactionAmount: number;

    @Column('varchar')
    transactionDescription: string;

    @Column('int')
    transactionRemainAmount: number;
}