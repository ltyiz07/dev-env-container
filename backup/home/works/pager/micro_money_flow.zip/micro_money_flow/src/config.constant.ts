export const envConfig = {
    kakaobankFilePassword: '950617',
    kakaopayFilePassword: '19950617',
    kbankFilePassword: '950617',
    shinhanbankFilePassword: '950617',
    tossbankFilePassword: '950617',
} as const;