import { BankAccountName } from "./banks.enum";

export interface ICommonTransaction {
    bankAccountName: BankAccountName;
    transactionDatatime: Date;
    transactionAmount: number;
    transactionDescription: string;
    transactionRemainAmount: number;
}
