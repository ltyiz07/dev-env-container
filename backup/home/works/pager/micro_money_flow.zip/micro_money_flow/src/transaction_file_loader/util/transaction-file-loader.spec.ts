import { BankAccountName } from "../interface/banks.enum";
import { loadTransactionFiles } from "./transaction-file-loader";

describe('transactionFileLoader utility function test', () => {
    it('kakaobank file loader test', async () => {
        const res = await loadTransactionFiles(BankAccountName.KAKAOBANK);
    });
    it('kakaopay file loader test', async () => {
        const res = await loadTransactionFiles(BankAccountName.KAKAOPAY);
    });
    it('kbank file loader test', async () => {
        const res = await loadTransactionFiles(BankAccountName.KBANK);
    });
    it('shinhanbank file loader test', async () => {
        const res = await loadTransactionFiles(BankAccountName.SHINHANBANK);
    });
    it('tossbank file loader test', async () => {
        const res = await loadTransactionFiles(BankAccountName.TOSSBANK);
    });
})
