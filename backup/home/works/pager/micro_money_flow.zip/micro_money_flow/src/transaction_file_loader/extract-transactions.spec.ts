import { envConfig } from "../config.constant";
import { extractTransactions } from "./extract-transactions";
import { BankAccountName } from "./interface/banks.enum";

describe('Load transaction files as common data-form interface', () => {
    it('load kakao-pay transactions', async () => {
        const transactions = await extractTransactions(BankAccountName.KAKAOPAY, envConfig.kakaopayFilePassword);
        let remainAmount = 0;
        transactions.forEach(transaction => {
            Number(transaction.transactionAmount);
            remainAmount = remainAmount + transaction.transactionAmount;
        });
        expect(transactions[transactions.length - 1].transactionRemainAmount).toBe(remainAmount);
    }, 1000 * 30);

    it('load kakao-bank transactions', async () => {
        const transactions = await extractTransactions(BankAccountName.KAKAOBANK, envConfig.kakaobankFilePassword);
        const amounts = transactions.map(transactions => transactions.transactionAmount);
        expect(amounts.reduce((prev, curr) => prev + curr, 0)).toBe(transactions[transactions.length - 1].transactionRemainAmount);
    })

    it('load k-bank transactions', async () => {
        const transactions = await extractTransactions(BankAccountName.KBANK, envConfig.kbankFilePassword);
        const amounts = transactions.map(transactions => transactions.transactionAmount);
        expect(amounts.reduce((prev, curr) => prev + curr, 0)).toBe(transactions[transactions.length - 1].transactionRemainAmount);
    })

    it('load shinhan-bank 1 transactions', async () => {
        const transactions = await extractTransactions(BankAccountName.SHINHANBANK, envConfig.shinhanbankFilePassword);
        const amounts = transactions.map(transactions => transactions.transactionAmount);
        expect(amounts.reduce((prev, curr) => prev + curr, 0)).toBe(transactions[transactions.length - 1].transactionRemainAmount);
    })

    it('load shinhan-bank 2 transactions', async () => {
        const transactions = await extractTransactions(BankAccountName.SHINHANBANK2, envConfig.shinhanbankFilePassword);
        const amounts = transactions.map(transactions => transactions.transactionAmount);
        expect(amounts.reduce((prev, curr) => prev + curr, 0)).toBe(transactions[transactions.length - 1].transactionRemainAmount);
    })

    it('load toss-bank transactions', async () => {
        const transactions = await extractTransactions(BankAccountName.TOSSBANK, envConfig.tossbankFilePassword);
        const amounts = transactions.map(transactions => transactions.transactionAmount);
        expect(amounts.reduce((prev, curr) => prev + curr, 0)).toBe(transactions[transactions.length - 1].transactionRemainAmount);
    })
})