import { read } from "xlsx";
import { IKakaopayDataform, KakaopayDataformKeys } from "../interface/per_banks/kakaopay.interface";
import { decryptExcelFile } from "../util/decrypt-excel-file";
import { sheetToKVMap } from "../util/worksheet-to-kv-map";

export const parseKakaopayXL = async (buffer: Buffer, filePassword: string): Promise<IKakaopayDataform[]> => {
    const decryptedBuffer = await decryptExcelFile(buffer, filePassword);

    // Parse the decrypted excel file
    const res = read(decryptedBuffer, { type: 'buffer' });
    if (res.SheetNames.length !== 1) {
        throw new Error('Excel file should have only one sheet');
    }

    // Convert the parsed excel file to key-value json
    const kvs = await sheetToKVMap(
        res.Sheets[res.SheetNames[0]],
        Object.values(KakaopayDataformKeys),
    );

    // Convert the key-value json to the desired dataform
    return kvs.map((kv) => {
        return {
            transactionDatatime: String(kv[KakaopayDataformKeys.transactionDatatime]),
            transactionType: String(kv[KakaopayDataformKeys.transactionType]),
            transactionAmount: String(kv[KakaopayDataformKeys.transactionAmount]),
            transactionRemainAmount: String(kv[KakaopayDataformKeys.transactionRemainAmount]),
            transactionBank: String(kv[KakaopayDataformKeys.transactionBank]),
            transactionDescription: String(kv[KakaopayDataformKeys.transactionDescription]),
        };
    });
};
