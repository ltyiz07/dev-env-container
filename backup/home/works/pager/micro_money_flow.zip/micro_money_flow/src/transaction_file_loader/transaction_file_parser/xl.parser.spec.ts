import { envConfig } from "../../config.constant";
import { BankAccountName } from "../interface/banks.enum";
import { IKakaobankDataform } from "../interface/per_banks/kakaobank.interface";
import { IKakaopayDataform } from "../interface/per_banks/kakaopay.interface";
import { IKbankDataform } from "../interface/per_banks/kbank.interface";
import { IShinhanbankDataform } from "../interface/per_banks/shinhanbank.interface";
import { IShinhanbank2Dataform } from "../interface/per_banks/shinhanbank2.interface";
import { ITossbankDataform } from "../interface/per_banks/tossbank.interface";
import { loadTransactionFiles } from "../util/transaction-file-loader";
import { parseKakaobankXL } from "./kakaobank.xl.parser";
import { parseKakaopayXL } from "./kakaopay.xl.parser";
import { parseKbankXL } from "./kbank.xl.parser";
import { parseShinhanbankXL } from "./shinhanbank.xl.parser";
import { parseShinhanbank2XL } from "./shinhanbank2.xl.parser";
import { parseTossbankXL } from "./tossbank.xl.parser";

describe('Excel file parser', () => {
    it('Kakao-pay parse content test', async () => {
        const buffers = await loadTransactionFiles(BankAccountName.KAKAOPAY);

        const res: IKakaopayDataform[] = [];
        for (const buffer of buffers) {
            const parsedItems = await parseKakaopayXL(buffer, envConfig.kakaopayFilePassword);
            res.push(...parsedItems);
        }
        const tTypes = res.map((kv) => {
            return kv.transactionType
        })
        const uniqueTypes = tTypes.reduce((prev, curr) => {
            return { ...prev, [curr]: true }
        }, {});

        expect(Object.keys(uniqueTypes).length).toBe(16);
        expect(res[0].transactionAmount).toBeDefined();
    });

    it('Kakao-bank parse content test', async () => {
        const buffers = await loadTransactionFiles(BankAccountName.KAKAOBANK);
        const res: IKakaobankDataform[] = [];
        for (const buffer of buffers) {
            const parsedItems = await parseKakaobankXL(buffer, envConfig.kakaobankFilePassword);
            res.push(...parsedItems);
        }

        expect(res[0].transactionAmount).toBeDefined();
    });

    it('K-bank parse content test', async () => {
        const buffers = await loadTransactionFiles(BankAccountName.KBANK);
        const res: IKbankDataform[] = [];
        for (const buffer of buffers) {
            const parsedItems = await parseKbankXL(buffer, envConfig.kbankFilePassword);
            res.push(...parsedItems);
        }

        expect(res[0].transactionInAmount).toBeDefined();
    });

    it('Shinhan-bank 1 parse content test', async () => {
        const buffers = await loadTransactionFiles(BankAccountName.SHINHANBANK);
        const res: IShinhanbankDataform[] = [];
        for (const buffer of buffers) {
            const parsedItems = await parseShinhanbankXL(buffer, envConfig.shinhanbankFilePassword);
            res.push(...parsedItems);
        }

        expect(res[0].transactionInAmount).toBeDefined();
    });

    it('Shinhan-bank 2 parse content test', async () => {
        const buffers = await loadTransactionFiles(BankAccountName.SHINHANBANK2);
        const res: IShinhanbank2Dataform[] = [];
        for (const buffer of buffers) {
            const parsedItems = await parseShinhanbank2XL(buffer, envConfig.shinhanbankFilePassword);
            res.push(...parsedItems);
        }

        expect(res[0].transactionInAmount).toBeDefined();
    });

    it('toss-bank parse content test', async () => {
        const buffers = await loadTransactionFiles(BankAccountName.TOSSBANK);
        const res: ITossbankDataform[] = [];
        for (const buffer of buffers) {
            const parsedItems = await parseTossbankXL(buffer, envConfig.tossbankFilePassword);
            res.push(...parsedItems);
        }

        expect(res[0].transactionAmount).toBeDefined();
    });
});