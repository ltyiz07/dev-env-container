import { BankAccountName } from "./interface/banks.enum";
import { IKakaopayDataform } from "./interface/per_banks/kakaopay.interface";
import { IKbankDataform } from "./interface/per_banks/kbank.interface";
import { IShinhanbankDataform } from "./interface/per_banks/shinhanbank.interface";
import { IShinhanbank2Dataform } from "./interface/per_banks/shinhanbank2.interface";
import { ITossbankDataform } from "./interface/per_banks/tossbank.interface";
import { ICommonTransaction } from "./interface/transaction.interface";
import { parseKakaobankXL } from "./transaction_file_parser/kakaobank.xl.parser";
import { parseKakaopayXL } from "./transaction_file_parser/kakaopay.xl.parser";
import { parseKbankXL } from "./transaction_file_parser/kbank.xl.parser";
import { parseShinhanbankXL } from "./transaction_file_parser/shinhanbank.xl.parser";
import { parseShinhanbank2XL } from "./transaction_file_parser/shinhanbank2.xl.parser";
import { parseTossbankXL } from "./transaction_file_parser/tossbank.xl.parser";
import { loadTransactionFiles } from "./util/transaction-file-loader";

const kakaopayTransactions = async (password: string): Promise<ICommonTransaction[]> => {
    const buffers = await loadTransactionFiles(BankAccountName.KAKAOPAY);
    const kakaopayDataforms: IKakaopayDataform[] = [];
    for (const buffer of buffers) {
        const parsedItems = await parseKakaopayXL(buffer, password);
        kakaopayDataforms.push(...parsedItems);
    }

    const commonTransactions: ICommonTransaction[] = kakaopayDataforms
        .map(dataform => {
            const amountSign = dataform.transactionType.includes('[+]') ? '+' : '-';
            const transactionAmount = parseInt(`${amountSign}${dataform.transactionAmount}`);
            return {
                bankAccountName: BankAccountName.KAKAOPAY,
                transactionDatatime: new Date(dataform.transactionDatatime),
                transactionAmount,
                transactionDescription: `${dataform.transactionType} : ${dataform.transactionDescription}`,
                transactionRemainAmount: parseInt(dataform.transactionRemainAmount),
            }
        });

    return commonTransactions;
}

const kakaobankTransactions = async (password: string): Promise<ICommonTransaction[]> => {
    const buffers = await loadTransactionFiles(BankAccountName.KAKAOBANK);
    const kakaobankDataforms: IKakaopayDataform[] = [];
    for (const buffer of buffers) {
        const parsedItems = await parseKakaobankXL(buffer, password);
        kakaobankDataforms.push(...parsedItems);
    }

    const commonTransactions: ICommonTransaction[] = kakaobankDataforms
        .map(dataform => {
            return {
                bankAccountName: BankAccountName.KAKAOBANK,
                transactionDatatime: new Date(dataform.transactionDatatime),
                transactionAmount: parseInt(dataform.transactionAmount.replace(/,/g, '')),
                transactionRemainAmount: parseInt(dataform.transactionRemainAmount.replace(/,/g, '')),
                transactionDescription: `${dataform.transactionType} : ${dataform.transactionDescription}`,
            }
        });

    return commonTransactions;
}

const kbankTransactions = async (password: string): Promise<ICommonTransaction[]> => {
    const buffers = await loadTransactionFiles(BankAccountName.KBANK);
    const kbankDataforms: IKbankDataform[] = [];
    for (const buffer of buffers) {
        const parsedItems = await parseKbankXL(buffer, password);
        kbankDataforms.push(...parsedItems);
    }

    const commonTransactions: ICommonTransaction[] = kbankDataforms
        .map(dataform => {
            let transactionAmount = 0;
            transactionAmount += parseInt(dataform.transactionInAmount.replace(/,/g, ''));
            transactionAmount -= parseInt(dataform.transactionOutAmount.replace(/,/g, ''));
            return {
                bankAccountName: BankAccountName.KBANK,
                transactionDatatime: new Date(dataform.transactionDatatime),
                transactionAmount,
                transactionRemainAmount: parseInt(dataform.transactionRemainAmount.replace(/,/g, '')),
                transactionDescription: `${dataform.transactionMethod} : ${dataform.transactionDescription} ` +
                    `- ${dataform.transactionTargetAccountBank} ` +
                    `${dataform.transactionTargetAccountName} ` +
                    `${dataform.transactionTargetAccountNumber}`,
            }
        });

    return commonTransactions;
}

const shinhanbankTransactions = async (password: string): Promise<ICommonTransaction[]> => {
    const buffers = await loadTransactionFiles(BankAccountName.SHINHANBANK);
    const shinhanbankDataforms: IShinhanbankDataform[] = [];
    for (const buffer of buffers) {
        const parsedItems = await parseShinhanbankXL(buffer, password);
        shinhanbankDataforms.push(...parsedItems);
    }
    const commonTransactions: ICommonTransaction[] = shinhanbankDataforms
        .map(dataform => {
            let transactionAmount = 0;
            transactionAmount += parseInt(dataform.transactionInAmount.replace(/,/g, ''));
            transactionAmount -= parseInt(dataform.transactionOutAmount.replace(/,/g, ''));

            return {
                bankAccountName: BankAccountName.SHINHANBANK,
                transactionDatatime: new Date(`${dataform.transactionDate} ${dataform.transactionTime}`),
                transactionAmount,
                transactionRemainAmount: parseInt(dataform.transactionRemainAmount.replace(/,/g, '')),
                transactionDescription: `${dataform.transactionMethod} : ${dataform.transactionDescription} ` +
                    `at ${dataform.transactionOffice}`,
            }
        });
    return commonTransactions;
}

const shinhanbank2Transactions = async (password: string): Promise<ICommonTransaction[]> => {
    const buffers = await loadTransactionFiles(BankAccountName.SHINHANBANK2);
    const shinhanbank2Dataforms: IShinhanbank2Dataform[] = [];
    for (const buffer of buffers) {
        const parsedItems = await parseShinhanbank2XL(buffer, password);
        shinhanbank2Dataforms.push(...parsedItems);
    }
    const commonTransactions: ICommonTransaction[] = shinhanbank2Dataforms
        .map(dataform => {
            let transactionAmount = 0;
            transactionAmount += parseInt(dataform.transactionInAmount.replace(/,/g, ''));
            transactionAmount -= parseInt(dataform.transactionOutAmount.replace(/,/g, ''));

            return {
                bankAccountName: BankAccountName.SHINHANBANK2,
                transactionDatatime: new Date(`${dataform.transactionDate} 00:00:00`),
                transactionAmount,
                transactionRemainAmount: parseInt(dataform.transactionRemainAmount.replace(/,/g, '')),
                transactionDescription: `${dataform.transactionMethod} at ${dataform.transactionOffice}`
            }
        });
    return commonTransactions;
}

const tossBankTransactions = async (password: string): Promise<ICommonTransaction[]> => {
    const buffers = await loadTransactionFiles(BankAccountName.TOSSBANK);
    const tossbankDataforms: ITossbankDataform[] = [];
    for (const buffer of buffers) {
        const parsedItems = await parseTossbankXL(buffer, password);
        tossbankDataforms.push(...parsedItems);
    }
    const commonTransactions: ICommonTransaction[] = tossbankDataforms
        .map(dataform => {
            const transactionAmount = parseInt(dataform.transactionAmount.replace(/,/g, ''));
            let transactionRemainAmount = parseInt(dataform.transactionRemainAmount.replace(/,/g, ''));
            if (isNaN(transactionRemainAmount)) {
                transactionRemainAmount = transactionAmount;
            }
            return {
                bankAccountName: BankAccountName.TOSSBANK,
                transactionDatatime: new Date(dataform.transactionDatatime),
                transactionAmount,
                transactionRemainAmount,
                transactionDescription: `${dataform.transactionMethod} : ${dataform.transactionDescription}`,
            }
        });
    return commonTransactions;
}

const cvtTransactions: { [key in BankAccountName]: (password: string) => Promise<ICommonTransaction[]> } = {
    [BankAccountName.KAKAOBANK]: kakaobankTransactions,
    [BankAccountName.KAKAOPAY]: kakaopayTransactions,
    [BankAccountName.KBANK]: kbankTransactions,
    [BankAccountName.SHINHANBANK]: shinhanbankTransactions,
    [BankAccountName.SHINHANBANK2]: shinhanbank2Transactions,
    [BankAccountName.TOSSBANK]: tossBankTransactions,
}

export const extractTransactions = async (bankName: BankAccountName, password: string): Promise<ICommonTransaction[]> => {
    const commonTransactions = await cvtTransactions[bankName](password);

    // Sort by transaction datetime ASC
    commonTransactions.sort((a, b) => {
        return a.transactionDatatime.getTime() - b.transactionDatatime.getTime()
    });

    return commonTransactions;
}