export interface IShinhanbankDataform {
    transactionDate: string;
    transactionTime: string;
    transactionMethod: string;
    transactionOutAmount: string;
    transactionInAmount: string;
    transactionDescription: string;
    transactionRemainAmount: string;
    transactionOffice: string;
}

export const ShinhanbankDataformKeys: {[key in keyof IShinhanbankDataform]: string} = {
    transactionDate: '거래일자',
    transactionTime: '거래시간',
    transactionMethod: '적요',
    transactionOutAmount: '출금(원)',
    transactionInAmount: '입금(원)',
    transactionDescription: '내용',
    transactionRemainAmount: '잔액(원)',
    transactionOffice: '거래점',
} as const
