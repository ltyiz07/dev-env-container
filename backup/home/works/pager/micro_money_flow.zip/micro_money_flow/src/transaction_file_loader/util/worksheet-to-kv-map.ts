import { utils, WorkSheet } from "xlsx";

export const sheetToKVMap = async (sheet: WorkSheet, excelKeys: string[]): Promise<{ [key: string]: unknown }[]> => {
    const jsonSheet = utils.sheet_to_json(sheet, { header: 1 });

    const headerIndex = jsonSheet.findIndex((row: string[]) => {
        return excelKeys.map(excelKey => {
            return row.includes(excelKey);
        }).every(Boolean);;
    });
    if (headerIndex < 0) {
        throw new Error('Failed to find the header row');
    }

    const headerRow: string[] = jsonSheet[headerIndex] as string[];
    const keyIndex = headerRow.reduce((prev, cur, index) => {
        return { ...prev, [cur]: index };
    }, {});
    const valueArray = jsonSheet.slice(headerIndex + 1)
        .map(valueAr => {
            return Object.entries(keyIndex).reduce((prev, [key, idx]) => {
                return { ...prev, [key]: valueAr[idx as number] };
            }, {})
        });
    return valueArray;
}