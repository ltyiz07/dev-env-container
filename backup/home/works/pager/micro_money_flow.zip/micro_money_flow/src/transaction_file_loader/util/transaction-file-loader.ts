import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { BankAccountName } from "../interface/banks.enum";

const loadFilesByBankName = (bankName: BankAccountName): string[] => {
    const rawDataDir = join(__dirname, '..', '..', '..', 'raw_data');
    const bankDirs = {
        [BankAccountName.KAKAOBANK]: join(rawDataDir, 'kakaobank'),
        [BankAccountName.KAKAOPAY]: join(rawDataDir, 'kakaopay'),
        [BankAccountName.KBANK]: join(rawDataDir, 'kbank'),
        [BankAccountName.SHINHANBANK]: join(rawDataDir, 'shinhanbank'),
        [BankAccountName.SHINHANBANK2]: join(rawDataDir, 'shinhanbank2'),
        [BankAccountName.TOSSBANK]: join(rawDataDir, 'tossbank'),
    } as const;

    return readdirSync(bankDirs[bankName])
        .map(file => join(bankDirs[bankName], file));
}

export const loadTransactionFiles = async (bank: BankAccountName): Promise<Buffer[]> => {
    const files = loadFilesByBankName(bank);
    return files.map(path => {
        return readFileSync(path);
    })
};