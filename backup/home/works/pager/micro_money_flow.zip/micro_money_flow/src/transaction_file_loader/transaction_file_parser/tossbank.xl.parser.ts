import { read } from "xlsx";
import { ITossbankDataform, TossbankDataformKeys } from "../interface/per_banks/tossbank.interface";
import { sheetToKVMap } from "../util/worksheet-to-kv-map";

export const parseTossbankXL = async (buffer: Buffer, filePassword: string): Promise<ITossbankDataform[]> => {
    const res = read(buffer, { type: 'buffer' });
    if (res.SheetNames.length !== 1) {
        throw new Error('Excel file should have only one sheet');
    }

    const kvs = await sheetToKVMap(
        res.Sheets[res.SheetNames[0]],
        Object.values(TossbankDataformKeys),
    );

    return kvs.map((kv) => {
        return {
            transactionDatatime: String(kv[TossbankDataformKeys.transactionDatatime]),
            transactionDescription: String(kv[TossbankDataformKeys.transactionDescription]),
            transactionMethod: String(kv[TossbankDataformKeys.transactionMethod]),
            transactionAmount: String(kv[TossbankDataformKeys.transactionAmount]),
            transactionRemainAmount: String(kv[TossbankDataformKeys.transactionRemainAmount]),
        };
    })
}