import { read } from "xlsx";
import { IShinhanbankDataform, ShinhanbankDataformKeys } from "../interface/per_banks/shinhanbank.interface";
import { sheetToKVMap } from "../util/worksheet-to-kv-map";

export const parseShinhanbankXL = async (buffer: Buffer, filePassword: string): Promise<IShinhanbankDataform[]> => {
    const res = read(buffer, { type: 'buffer', password: filePassword });
    if (res.SheetNames.length !== 1) {
        throw new Error('Excel file should have only one sheet');
    }

    const kvs = await sheetToKVMap(
        res.Sheets[res.SheetNames[0]],
        Object.values(ShinhanbankDataformKeys),
    );

    return kvs.map((kv) => {
        return {
            transactionDate: String(kv[ShinhanbankDataformKeys.transactionDate]),
            transactionTime: String(kv[ShinhanbankDataformKeys.transactionTime]),
            transactionMethod: String(kv[ShinhanbankDataformKeys.transactionMethod]),
            transactionOutAmount: String(kv[ShinhanbankDataformKeys.transactionOutAmount]),
            transactionInAmount: String(kv[ShinhanbankDataformKeys.transactionInAmount]),
            transactionDescription: String(kv[ShinhanbankDataformKeys.transactionDescription]),
            transactionRemainAmount: String(kv[ShinhanbankDataformKeys.transactionRemainAmount]),
            transactionOffice: String(kv[ShinhanbankDataformKeys.transactionOffice]),
        };
    })
}