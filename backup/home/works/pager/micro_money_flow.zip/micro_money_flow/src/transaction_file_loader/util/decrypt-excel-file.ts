import * as XlsxPopulate from 'xlsx-populate';

export const decryptExcelFile = async (buffer: Buffer, filePassword: string) => {
    const workbook = await XlsxPopulate.fromDataAsync(buffer, { password: filePassword });
    return await workbook.outputAsync();
}