export interface IKakaobankDataform {
    transactionDatatime: string;
    transactionType: string;
    transactionAmount: string;
    transactionRemainAmount: string;
    transactionMethod: string;
    transactionDescription: string;
}

export const KakaobankDataformKeys: {[key in keyof IKakaobankDataform]: string} = {
    transactionDatatime: '거래일시',
    transactionType: '구분',
    transactionAmount: '거래금액',
    transactionRemainAmount: '거래 후 잔액',
    transactionMethod: '거래구분',
    transactionDescription: '내용',
} as const