export interface IKbankDataform {
    transactionDatatime: string;
    transactionMethod: string;
    transactionInAmount: string;
    transactionOutAmount: string;
    transactionRemainAmount: string;
    transactionTargetAccountName: string;
    transactionTargetAccountBank: string;
    transactionTargetAccountNumber: string;
    transactionDescription: string;
}

export const KbankDataformKeys: {[key in keyof IKbankDataform]: string} = {
    transactionDatatime: '거래일시',
    transactionMethod: '거래구분',
    transactionInAmount: '입금금액',
    transactionOutAmount: '출금금액',
    transactionRemainAmount: '잔액',
    transactionTargetAccountName: '상대 예금주명',
    transactionTargetAccountBank: '상대 은행',
    transactionTargetAccountNumber: '상대 계좌번호',
    transactionDescription: '적요내용',
} as const