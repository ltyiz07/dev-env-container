export interface IShinhanbank2Dataform {
    transactionDate: string;
    transactionMethod: string;
    transactionOutAmount: string;
    transactionInAmount: string;
    transactionRemainAmount: string;
    transactionDescription: string;
    preferentialInterestRate: string;
    partneredAdditionalInterestRate: string;
    transactionOffice: string;

}

export const Shinhanbank2DataformKeys: { [key in keyof IShinhanbank2Dataform]: string } = {
    transactionDate: '거래일자 ',
    transactionMethod: '적요 ',
    transactionOutAmount: '출금(원)',
    transactionInAmount: '입금(원)',
    transactionRemainAmount: '잔액(원)',
    transactionDescription: '내용',
    preferentialInterestRate: '우대금리(%)',
    partneredAdditionalInterestRate: '제휴가산금리(%)',
    transactionOffice: '거래점',
} as const
