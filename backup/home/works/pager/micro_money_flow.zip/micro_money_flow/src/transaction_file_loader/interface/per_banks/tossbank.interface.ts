export interface ITossbankDataform {
    transactionDatatime: string;
    transactionDescription: string;
    transactionMethod: string;
    transactionAmount: string;
    transactionRemainAmount: string;
}

export const TossbankDataformKeys: {[key in keyof ITossbankDataform]: string} = {
    transactionDatatime: '거래 일시',
    transactionDescription: '적요',
    transactionMethod: '거래 유형',
    transactionAmount: '거래 금액',
    transactionRemainAmount: '거래 후 잔액',
}