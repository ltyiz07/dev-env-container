enum KakaypayTransactionTypeSample {
    '[+] 부족분충전',
    '[-] 송금',
    '[+] 받기',
    '[-] 결제',
    '[-] 내계좌로_내보내기',
    '[+] 적립',
    '[+] 충전',
    '[-] 출금',
    '[+] 입금',
    '[+] 이자',
    '[+] 결제취소',
    '[-] 소호결제',
    '[+] 송금 기간만료',
    '[-] 코드송금',
    '[+] 송금취소',
    '[-] 예약송금'
}

export interface IKakaopayDataform {
    transactionDatatime: string;
    transactionType: string;
    transactionAmount: string;
    transactionRemainAmount: string;
    transactionBank?: string;
    transactionDescription: string;
}

export const KakaopayDataformKeys: {[key in keyof IKakaopayDataform]: string} = {
    transactionDatatime: '거래일시',
    transactionType: '거래구분',
    transactionAmount: '거래금액',
    transactionRemainAmount: '거래 후 잔액',
    transactionBank: '은행',
    transactionDescription: '계좌 정보 / 결제 정보',
} as const