import { read } from "xlsx";
import { IShinhanbank2Dataform, Shinhanbank2DataformKeys } from "../interface/per_banks/shinhanbank2.interface";
import { sheetToKVMap } from "../util/worksheet-to-kv-map";

export const parseShinhanbank2XL = async (buffer: Buffer, filePassword: string): Promise<IShinhanbank2Dataform[]> => {
    const res = read(buffer, { type: 'buffer', password: filePassword });
    if (res.SheetNames.length !== 1) {
        throw new Error('Excel file should have only one sheet');
    }

    const kvs = await sheetToKVMap(
        res.Sheets[res.SheetNames[0]],
        Object.values(Shinhanbank2DataformKeys),
    );

    return kvs.map((kv) => {
        return {
            transactionDate: String(kv[Shinhanbank2DataformKeys.transactionDate]),
            transactionMethod: String(kv[Shinhanbank2DataformKeys.transactionMethod]),
            transactionOutAmount: String(kv[Shinhanbank2DataformKeys.transactionOutAmount]),
            transactionInAmount: String(kv[Shinhanbank2DataformKeys.transactionInAmount]),
            transactionRemainAmount: String(kv[Shinhanbank2DataformKeys.transactionRemainAmount]),
            transactionDescription: String(kv[Shinhanbank2DataformKeys.transactionDescription]),
            preferentialInterestRate: String(kv[Shinhanbank2DataformKeys.preferentialInterestRate]),
            partneredAdditionalInterestRate: String(kv[Shinhanbank2DataformKeys.partneredAdditionalInterestRate]),
            transactionOffice: String(kv[Shinhanbank2DataformKeys.transactionOffice]),
        };
    })
}