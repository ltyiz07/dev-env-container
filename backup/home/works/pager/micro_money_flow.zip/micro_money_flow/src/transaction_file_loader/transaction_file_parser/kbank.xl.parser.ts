import { read } from "xlsx";
import { IKbankDataform, KbankDataformKeys } from "../interface/per_banks/kbank.interface";
import { decryptExcelFile } from "../util/decrypt-excel-file";
import { sheetToKVMap } from "../util/worksheet-to-kv-map";


export const parseKbankXL = async (buffer: Buffer, filePassword: string): Promise<IKbankDataform[]> => {
    const decryptedBuffer = await decryptExcelFile(buffer, filePassword);

    const res = read(decryptedBuffer, { type: 'buffer' });
    if (res.SheetNames.length !== 1) {
        throw new Error('Excel file should have only one sheet');
    }

    const kvs = await sheetToKVMap(
        res.Sheets[res.SheetNames[0]],
        Object.values(KbankDataformKeys),
    );

    return kvs.map((kv) => {
        return {
            transactionDatatime: String(kv[KbankDataformKeys.transactionDatatime]),
            transactionMethod: String(kv[KbankDataformKeys.transactionMethod]),
            transactionInAmount: String(kv[KbankDataformKeys.transactionInAmount]),
            transactionOutAmount: String(kv[KbankDataformKeys.transactionOutAmount]),
            transactionRemainAmount: String(kv[KbankDataformKeys.transactionRemainAmount]),
            transactionTargetAccountName: String(kv[KbankDataformKeys.transactionTargetAccountName]),
            transactionTargetAccountBank: String(kv[KbankDataformKeys.transactionTargetAccountBank]),
            transactionTargetAccountNumber: String(kv[KbankDataformKeys.transactionTargetAccountNumber]),
            transactionDescription: String(kv[KbankDataformKeys.transactionDescription]),
        };
    });
};
