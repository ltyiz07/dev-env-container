import { read } from "xlsx";
import { IKakaobankDataform, KakaobankDataformKeys } from "../interface/per_banks/kakaobank.interface";
import { decryptExcelFile } from "../util/decrypt-excel-file";
import { sheetToKVMap } from "../util/worksheet-to-kv-map";

export const parseKakaobankXL = async (buffer: Buffer, filePassword: string): Promise<IKakaobankDataform[]> => {
    const decryptedBuffer = await decryptExcelFile(buffer, filePassword);

    const res = read(decryptedBuffer, { type: 'buffer' });
    if (res.SheetNames.length !== 1) {
        throw new Error('Excel file should have only one sheet');
    }

    const kvs = await sheetToKVMap(
        res.Sheets[res.SheetNames[0]],
        Object.values(KakaobankDataformKeys)
    );

    return kvs.map((kv) => {
        return {
            transactionDatatime: String(kv[KakaobankDataformKeys.transactionDatatime]),
            transactionType: String(kv[KakaobankDataformKeys.transactionType]),
            transactionAmount: String(kv[KakaobankDataformKeys.transactionAmount]),
            transactionRemainAmount: String(kv[KakaobankDataformKeys.transactionRemainAmount]),
            transactionMethod: String(kv[KakaobankDataformKeys.transactionMethod]),
            transactionDescription: String(kv[KakaobankDataformKeys.transactionDescription]),
        };
    });
}