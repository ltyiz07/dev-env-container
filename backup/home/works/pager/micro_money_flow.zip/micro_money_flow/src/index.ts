import { envConfig } from './config.constant';
import { AppDataSource } from './data-source';
import { BankTransaction } from './entity/bank-transaction.entity';
import { extractTransactions } from './transaction_file_loader/extract-transactions';
import { BankAccountName } from './transaction_file_loader/interface/banks.enum';

const main = async () => {
  const dataSource = await AppDataSource.initialize();
  const bankTransaction = await dataSource.manager.find(BankTransaction);

  const kakaypayTransactions = await extractTransactions(BankAccountName.KAKAOPAY, envConfig.kakaopayFilePassword);
  const kakaybankTransactions = await extractTransactions(BankAccountName.KAKAOBANK, envConfig.kakaobankFilePassword);
  const kbankTransactions = await extractTransactions(BankAccountName.KBANK, envConfig.kbankFilePassword);
  const shinhanbankTransactions = await extractTransactions(BankAccountName.SHINHANBANK, envConfig.shinhanbankFilePassword);
  const shinhanbank2Transactions = await extractTransactions(BankAccountName.SHINHANBANK2, envConfig.shinhanbankFilePassword);
  const tossbankTransactions = await extractTransactions(BankAccountName.TOSSBANK, envConfig.tossbankFilePassword);

  const totalTransactions = [
    ...kakaypayTransactions,
    ...kakaybankTransactions,
    ...kbankTransactions,
    ...shinhanbankTransactions,
    ...shinhanbank2Transactions,
    ...tossbankTransactions,
  ];

  console.log('start save for totalTransactions length:', totalTransactions.length);
  // await dataSource.manager.save(BankTransaction, totalTransactions);

  console.log('save completed');

  await dataSource.destroy();
  console.log('db connection destroyed');
}

main()
  .then(() => { console.log('Done') })
  .catch(error => console.log(error));