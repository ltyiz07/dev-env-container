import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { BankTransaction } from './entity/bank-transaction.entity';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: 'ltyiz07.iptime.org',
  port: 5432,
  username: 'pgdbuser',
  password: 'pgdbpass0232',
  database: 'pgdb',
  synchronize: true,
  logging: ['error', 'warn', 'migration', 'schema'],
  entities: [BankTransaction],
  migrations: [],
  subscribers: [],
  namingStrategy: new SnakeNamingStrategy(),
});
