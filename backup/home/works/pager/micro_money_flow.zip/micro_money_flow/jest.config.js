/** @type {import('ts-jest').JestConfigWithTsJest} **/
module.exports = {
  preset: "ts-jest",
  rootDir: "./",
  testEnvironment: "node",
  testPathIgnorePatterns: ["<rootDir>/node_modules", "<rootDir>/build/"],
  transform: {
    "^.+.tsx?$": ["ts-jest",{}],
  },
  testMatch: ["<rootDir>/src/**/*.spec.ts"],
};