#

## Progression

### 1. Parse files

- Parse xlsx files
- Parse pdf files

### 2. Extract data from files

- Extract as interface

### 3. Load to database

### 4. Load from LookerStudio

- Set-up looker studio with PostgreSQL connection
