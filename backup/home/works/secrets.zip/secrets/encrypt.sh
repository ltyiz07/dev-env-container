#! /bin/bash

cat secrets.json | jq '.' | gpg --no-symkey-cache -c > secrets_1.json.gpg
