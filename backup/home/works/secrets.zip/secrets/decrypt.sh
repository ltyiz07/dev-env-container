#!/bin/bash

gpg --no-symkey-cache --quiet -d ./secrets.json.gpg | jq '.'
