import binascii
import hashlib

# BIP-39 영어 워드리스트 (2048 단어)
with open("./mneo/bip_39_text.txt", "r") as file:
    wordlist = list(map(lambda x: x.strip(), file.readlines()))


def string_to_entropy(input_string, entropy_bits=128):
    """
    임의 문자열을 특정 길이의 Hex 엔트로피로 변환
    :param input_string: 입력 문자열
    :param entropy_bits: 원하는 엔트로피 길이 (128 또는 256)
    :return: Hex 형식의 엔트로피
    """
    # (1) 문자열을 SHA-256으로 해싱 (32바이트 = 256비트)
    sha256_hash = hashlib.sha256(input_string.encode("utf-8")).digest()

    # (2) 원하는 엔트로피 길이에 맞게 자름
    if entropy_bits not in [128, 256]:
        raise ValueError("entropy_bits는 128 또는 256만 지원됩니다.")

    entropy_bytes = entropy_bits // 8  # 128비트 = 16바이트, 256비트 = 32바이트
    entropy = sha256_hash[:entropy_bytes]  # 앞에서부터 자름

    return binascii.hexlify(entropy).decode("ascii")  # Hex 문자열로 변환


def generate_mnemonic_from_entropy(hex_entropy):
    # (1) Hex 엔트로피를 바이너리로 변환
    entropy_bytes = binascii.unhexlify(hex_entropy)
    entropy_bits = bin(int.from_bytes(entropy_bytes, "big"))[2:].zfill(
        len(entropy_bytes) * 8
    )

    # (2) 엔트로피 길이 확인 (128비트 또는 256비트만 지원 예시)
    entropy_length = len(entropy_bits)
    if entropy_length not in [128, 256]:
        raise ValueError(
            "엔트로피 길이는 128비트(16바이트) 또는 256비트(32바이트)여야 합니다."
        )

    # 체크섬 길이 계산 (엔트로피 길이 / 32)
    checksum_length = entropy_length // 32

    # (3) SHA-256 해시로 체크섬 생성
    entropy_hash = hashlib.sha256(entropy_bytes).digest()
    checksum_bits = bin(int.from_bytes(entropy_hash, "big"))[2:].zfill(256)[
        :checksum_length
    ]

    # (4) 엔트로피 + 체크섬 결합
    total_bits = entropy_bits + checksum_bits

    # (5) 11비트 단위로 분할
    chunks = [total_bits[i : i + 11] for i in range(0, len(total_bits), 11)]

    # (6) 각 11비트를 정수로 변환하고 워드리스트에서 단어 매핑
    mnemonic_words = []
    for chunk in chunks:
        word_index = int(chunk, 2)  # 11비트를 10진수로 변환 (0~2047)
        mnemonic_words.append(wordlist[word_index])

    return " ".join(mnemonic_words)


# 테스트용 Hex 엔트로피
# 128비트 엔트로피 (16바이트, Hex로 32자리) 예시
entropy_string = "4444444444" * 10
print("128비트 엔트로피로 생성된 뉴모닉:")
print(generate_mnemonic_from_entropy(string_to_entropy(entropy_string, 256)))
