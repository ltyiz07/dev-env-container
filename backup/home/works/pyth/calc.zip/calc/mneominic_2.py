import binascii
import hashlib
import hmac

from mnemonic import Mnemonic

# (1) 뉴모닉 입력
mnemo = Mnemonic("english")
mnemonic_phrase = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about"
passphrase = ""  # 선택적 패스프레이즈 (없으면 빈 문자열)

# (2) 뉴모닉에서 시드 생성
seed = mnemo.to_seed(mnemonic_phrase, passphrase=passphrase)
print("Seed:", seed.hex())  # 64바이트 시드 출력
