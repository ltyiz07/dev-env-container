from bip32 import BIP32
from mnemonic import Mnemonic

mnemo = Mnemonic("english")
words = "apple banana cherry ..."
seed = mnemo.to_seed(words, passphrase="")
