from .mneo.eng_words import wordlist
from .mneo.generate_mnemonic_from_entropy import generate_mnemonic_from_entropy
from .mneo.key_to_mfp import key_to_mfp
from .mneo.mnemonic_to_seed import mnemonic_to_seed
from .mneo.seed_to_master_key import seed_to_master_key
from .mneo.string_to_entropy import string_to_entropy

if __name__ == "__main__":
    # 뉴모닉 → 시드 → 키 → MFP 계산 가능

    # 1. Generate Mnemonic
    entropy = string_to_entropy("4444444444" * 10, 256)
    print("entropy: ", entropy)

    mnemonics = generate_mnemonic_from_entropy(entropy, wordlist)
    print("mnemonics: ", mnemonics)

    seed = mnemonic_to_seed(" ".join(mnemonics))
    print("seed: ", seed)

    master_priv, master_pub, chain_code = seed_to_master_key(seed)
    print("master_pub: ", master_pub)

    mfp = key_to_mfp(master_priv, True)
    print("mfp: ", mfp)
