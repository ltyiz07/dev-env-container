import binascii
import hashlib

from ecdsa import SECP256k1, SigningKey

from .ripemd160 import ripemd160


def key_to_mfp(key_hex, is_private=True):
    """
    키에서 마스터 핑거프린트(MFP) 생성
    :param key_hex: 개인키(32바이트 Hex) 또는 공개키(33바이트 Hex)
    :param is_private: True면 개인키, False면 공개키로 간주
    :return: MFP (8자리 Hex)
    """
    # (1) Hex를 바이트로 변환
    key_bytes = binascii.unhexlify(key_hex)

    # (2) 개인키인 경우 공개키 생성
    if is_private:
        if len(key_bytes) != 32:
            raise ValueError("개인키는 32바이트(64자리 Hex)여야 합니다.")
        sk = SigningKey.from_string(key_bytes, curve=SECP256k1)
        public_key = sk.get_verifying_key().to_string(
            "compressed"
        )  # 압축된 공개키 (33바이트)
    else:
        if len(key_bytes) not in [33, 65]:
            raise ValueError(
                "공개키는 33바이트(압축) 또는 65바이트(비압축)여야 합니다."
            )
        public_key = key_bytes

    # (3) SHA-256 해싱
    sha256_hash = hashlib.sha256(public_key).digest()

    # (4) RIPEMD-160 해싱
    ripemd160_hash = ripemd160(sha256_hash)

    # (5) 처음 4바이트 추출 (MFP)
    mfp = ripemd160_hash[:4]
    return mfp.hex()


if __name__ == "__main__":

    # 테스트
    # 마스터 개인키 예시 (시드에서 생성된 값)
    master_private_key = (
        "e8f32e723decf4051aefac8e2c93c9c5b214313817cdb01a1494b917c8436b35"
    )
    master_public_key = (
        "0339a36013301597daef41fbe593a02cc513d0b55527ec2df1050e2e8ff49c85c2"
    )

    print("마스터 개인키:", master_private_key)
    mfp_from_private = key_to_mfp(master_private_key, is_private=True)
    print("MFP (개인키에서):", mfp_from_private)

    print("\n마스터 공개키:", master_public_key)
    mfp_from_public = key_to_mfp(master_public_key, is_private=False)
    print("MFP (공개키에서):", mfp_from_public)
