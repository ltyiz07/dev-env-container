import binascii
import hashlib
import hmac

from bip32 import BIP32
from ecdsa import SECP256k1, SigningKey


def seed_to_master_key(seed_hex):
    """
    시드에서 마스터 키 생성 (BIP-32)
    :param seed_hex: 64바이트 시드 (Hex 형식)
    :return: 마스터 개인키, 마스터 공개키, 체인 코드 (Hex 형식)
    """
    # (1) Hex 시드를 바이너리로 변환
    seed = binascii.unhexlify(seed_hex)

    # (2) HMAC-SHA512로 마스터 키와 체인 코드 생성
    # 키: "Bitcoin seed", 데이터: 시드
    hmac_result = hmac.new(b"Bitcoin seed", seed, hashlib.sha512).digest()

    # (3) 결과 분리
    master_private_key = hmac_result[:32]  # 왼쪽 32바이트: 개인키
    master_chain_code = hmac_result[32:]  # 오른쪽 32바이트: 체인 코드

    # (4) 개인키에서 공개키 생성 (secp256k1 사용)
    sk = SigningKey.from_string(master_private_key, curve=SECP256k1)
    master_public_key = sk.get_verifying_key().to_string(
        "compressed"
    )  # 압축된 공개키 (33바이트)

    return (master_private_key.hex(), master_public_key.hex(), master_chain_code.hex())


def derive_child_key(seed_hex, path="m/44'/0'/0'/0/0"):
    """
    시드에서 특정 경로의 자식 키 파생
    :param seed_hex: 64바이트 시드 (Hex 형식)
    :param path: 파생 경로 (예: "m/44'/0'/0'/0/0")
    :return: 자식 개인키, 자식 공개키 (Hex 형식)
    """
    # BIP32 객체 생성
    seed = binascii.unhexlify(seed_hex)
    bip32 = BIP32.from_seed(seed)

    # 경로를 따라 자식 키 파생
    child_private_key = bip32.get_privkey_from_path(path)
    child_public_key = bip32.get_pubkey_from_path(path)

    return (child_private_key.hex(), child_public_key.hex())


if __name__ == "__main__":
    # 테스트
    seed = "1df480a1edd38333857c132d60e5528f2c4985f6d520feb05a17425450990f07966adb96774ab0a36a9e2dd6e7ec772c95347b72880e701bb584ad8d2aaac5a8"
    print("입력 시드:", seed)

    # 마스터 키 생성
    master_priv, master_pub, chain_code = seed_to_master_key(seed)
    print("\n마스터 개인키:", master_priv)
    print("마스터 공개키:", master_pub)
    print("체인 코드:", chain_code)

    # 자식 키 파생 (예: m/44'/0'/0'/0/0)
    child_priv, child_pub = derive_child_key(seed, "m/84'/0'/0'/1")
    print("\n자식 개인키:", child_priv)
    print("자식 공개키:", child_pub)
