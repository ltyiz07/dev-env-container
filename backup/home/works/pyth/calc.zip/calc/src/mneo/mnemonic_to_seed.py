import hashlib
import hmac
import unicodedata


def mnemonic_to_seed(mnemonic, passphrase=""):
    """
    뉴모닉에서 시드를 생성 (BIP-39)
    :param mnemonic: 뉴모닉 문장 (예: "apple banana cherry ...")
    :param passphrase: 선택적 패스프레이즈 (기본값: 빈 문자열)
    :return: 64바이트 시드 (Hex 형식)
    """
    # (1) 뉴모닉을 NFKD로 정규화
    mnemonic_normalized = unicodedata.normalize("NFKD", mnemonic)

    # (2) 솔트 생성: "mnemonic" + 패스프레이즈
    salt = "mnemonic" + passphrase
    salt_normalized = unicodedata.normalize("NFKD", salt).encode("utf-8")

    # (3) PBKDF2로 시드 생성
    # 비밀번호: 뉴모닉, 솔트: "mnemonic" + 패스프레이즈, 반복: 2048, 출력: 64바이트
    seed = hashlib.pbkdf2_hmac(
        hash_name="sha512",
        password=mnemonic_normalized.encode("utf-8"),
        salt=salt_normalized,
        iterations=2048,
        dklen=64,  # 512비트 = 64바이트
    )

    # (4) Hex 형식으로 반환
    return seed.hex()


if __name__ == "__main__":
    # 테스트
    mnemonic_12 = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about"
    mnemonic_24 = "zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo zoo vote"

    # 패스프레이즈 없이 테스트
    print("12단어 뉴모닉:", mnemonic_12)
    seed_12 = mnemonic_to_seed(mnemonic_12)
    print("시드 (패스프레이즈 없음):", seed_12)

    # 패스프레이즈 추가 테스트
    passphrase = "mypassword"
    seed_12_with_pass = mnemonic_to_seed(mnemonic_12, passphrase)
    print("시드 (패스프레이즈 'mypassword'):", seed_12_with_pass)

    print("\n24단어 뉴모닉:", mnemonic_24)
    seed_24 = mnemonic_to_seed(mnemonic_24)
    print("시드 (패스프레이즈 없음):", seed_24)
