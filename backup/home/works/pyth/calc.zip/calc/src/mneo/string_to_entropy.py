import binascii
import hashlib


def string_to_entropy(input_string, entropy_bits=128):
    """
    임의 문자열을 특정 길이의 Hex 엔트로피로 변환
    :param input_string: 입력 문자열
    :param entropy_bits: 원하는 엔트로피 길이 (128 또는 256)
    :return: Hex 형식의 엔트로피
    """
    # (1) 문자열을 SHA-256으로 해싱 (32바이트 = 256비트)
    sha256_hash = hashlib.sha256(input_string.encode("utf-8")).digest()

    # (2) 원하는 엔트로피 길이에 맞게 자름
    if entropy_bits not in [128, 256]:
        raise ValueError("entropy_bits는 128 또는 256만 지원됩니다.")

    entropy_bytes = entropy_bits // 8  # 128비트 = 16바이트, 256비트 = 32바이트
    entropy = sha256_hash[:entropy_bytes]  # 앞에서부터 자름

    return binascii.hexlify(entropy).decode("ascii")  # Hex 문자열로 변환
